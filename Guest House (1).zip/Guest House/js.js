let burger = document.querySelector('.burger')

let toggleBurger = ()=>{
    burger.classList.toggle('active')
}